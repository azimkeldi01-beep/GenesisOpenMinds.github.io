// Firebase: вход (Google / Apple / почта) + облачное хранение профиля и дней (Firestore).
// Подключается как ES-модуль; работает только если заполнен firebase-config.js.
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signInWithPopup, GoogleAuthProvider, OAuthProvider, signOut, sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";
import {
  getFirestore, doc, getDoc, setDoc, collection, getDocs
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js";

const cfg = window.FIREBASE_CONFIG;
const on = !!(cfg && cfg.apiKey && !/ВСТАВЬ/i.test(cfg.apiKey));

if (on) {
  const app = initializeApp(cfg);
  const auth = getAuth(app); auth.languageCode = "ru";
  const db = getFirestore(app);
  let pending = null;   // никнейм и фото, введённые при регистрации по почте
  let timer = null;

  const ERR = {
    "auth/invalid-credential": "Неверная почта или пароль.",
    "auth/wrong-password": "Неверная почта или пароль.",
    "auth/user-not-found": "Аккаунт с такой почтой не найден.",
    "auth/email-already-in-use": "Эта почта уже зарегистрирована — войдите.",
    "auth/weak-password": "Пароль слишком короткий (минимум 6 символов).",
    "auth/invalid-email": "Проверьте адрес почты.",
    "auth/popup-closed-by-user": "Окно входа закрыли до завершения.",
    "auth/cancelled-popup-request": "Окно входа закрыли до завершения.",
    "auth/popup-blocked": "Браузер заблокировал всплывающее окно — разрешите его для этого сайта.",
    "auth/unauthorized-domain": "Добавьте адрес сайта в Firebase → Authentication → Settings → Authorized domains.",
    "auth/operation-not-allowed": "Этот способ входа не включён в Firebase → Authentication → Sign-in method.",
    "auth/too-many-requests": "Слишком много попыток. Подождите немного.",
    "permission-denied": "Нет доступа к данным: проверьте правила Firestore (см. README).",
  };

  async function sync(fu) {
    if (!fu) { window.AG.onAuth(null); return; }
    const ref = doc(db, "users", fu.uid);
    if (pending) {
      await setDoc(ref, { nick: pending.nick, avatar: pending.avatar || "", email: fu.email || "", provider: "password" });
      pending = null;
    }
    const snap = await getDoc(ref);
    if (!snap.exists()) {   // вход через Google/Apple в первый раз: нужен никнейм и фото
      window.AG.onAuth({ id: fu.uid }, true, [], { name: fu.displayName || "" });
      return;
    }
    const days = (await getDocs(collection(db, "users", fu.uid, "days"))).docs.map(d => d.data());
    window.AG.onAuth({ id: fu.uid, ...snap.data() }, false, days);
  }

  onAuthStateChanged(auth, fu => sync(fu).catch(e => {
    console.error(e); window.AG.onAuth(null);
    document.querySelector("#toast").textContent = ERR[e.code] || "Ошибка Firebase: " + (e.message || e.code);
    document.querySelector("#toast").classList.add("show");
  }));

  window.AG_CLOUD = {
    enabled: true,
    errText: e => ERR[e.code] || e.message || "Что-то пошло не так.",
    async register(email, pass, profile) { pending = profile; try { await createUserWithEmailAndPassword(auth, email, pass); } catch (e) { pending = null; throw e; } },
    login: (email, pass) => signInWithEmailAndPassword(auth, email, pass),
    social: p => signInWithPopup(auth, p === "google" ? new GoogleAuthProvider() : new OAuthProvider("apple.com")),
    reset: email => sendPasswordResetEmail(auth, email),
    async saveProfile({ nick, avatar }) {
      const u = auth.currentUser;
      await setDoc(doc(db, "users", u.uid), { nick, avatar: avatar || "", email: u.email || "", provider: u.providerData[0]?.providerId || "password" });
      await sync(u);
    },
    logout: () => signOut(auth),
    // сохраняем папки-«дни» (текст, песня, настройки, готовое воспоминание). Сами файлы остаются в браузере.
    saveFolders(uid, folders) {
      clearTimeout(timer);
      timer = setTimeout(() => {
        folders.forEach(f => setDoc(doc(db, "users", uid, "days", f.id), JSON.parse(JSON.stringify(f))).catch(console.error));
      }, 800);
    },
  };
}
