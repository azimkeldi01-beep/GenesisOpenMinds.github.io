Положите сюда файл шрифта Coolvetica: coolvetica.woff2 или coolvetica.ttf.
Без него сайт использует похожий шрифт Fredoka.
