// =====================================================================
//  КОНФИГ FIREBASE — вставьте свои значения
//  Firebase Console → ⚙ Project settings → Your apps → </> Web app → SDK setup and configuration
//  Эти ключи публичные, их безопасно хранить в репозитории
//  (защита данных — это правила Firestore из README.md).
//  Пока стоят слова «ВСТАВЬТЕ», сайт работает в демо-режиме без Firebase.
// =====================================================================
window.FIREBASE_CONFIG = {
  apiKey: "ВСТАВЬТЕ_apiKey",
  authDomain: "ВСТАВЬТЕ_projectId.firebaseapp.com",
  projectId: "ВСТАВЬТЕ_projectId",
  storageBucket: "ВСТАВЬТЕ_projectId.firebasestorage.app",
  messagingSenderId: "ВСТАВЬТЕ",
  appId: "ВСТАВЬТЕ"
};
