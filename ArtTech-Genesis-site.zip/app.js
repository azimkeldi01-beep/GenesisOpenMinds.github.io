/* ArtTech Genesis — логика сайта.
   Всё работает в браузере (GitHub Pages): данные лежат в localStorage + IndexedDB.
   Вход через Google/Apple в демо-режиме; боевое подключение — см. README.md. */
"use strict";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
const PIXEL = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";

function toast(msg) {
  const t = $("#toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove("show"), 2800);
}
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtDate = iso => new Date(iso).toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" });

/* ================= IndexedDB для файлов ================= */
const DB = {
  _db: null,
  open() {
    if (this._db) return Promise.resolve(this._db);
    return new Promise((res, rej) => {
      const r = indexedDB.open("arttech-genesis", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("files");
      r.onsuccess = () => res((this._db = r.result));
      r.onerror = () => rej(r.error);
    });
  },
  async tx(mode, fn) {
    const db = await this.open();
    return new Promise((res, rej) => {
      const t = db.transaction("files", mode); const rq = fn(t.objectStore("files"));
      t.oncomplete = () => res(rq && rq.result); t.onerror = () => rej(t.error);
    });
  },
  put: (id, blob) => DB.tx("readwrite", s => s.put(blob, id)),
  get: id => DB.tx("readonly", s => s.get(id)),
  del: id => DB.tx("readwrite", s => s.delete(id)),
};
const urlCache = {};
async function fileUrl(id) {
  if (urlCache[id]) return urlCache[id];
  const b = await DB.get(id); if (!b) return null;
  return (urlCache[id] = URL.createObjectURL(b));
}

/* ================= Состояние ================= */
let users = JSON.parse(localStorage.getItem("ag_users") || "[]");
let user = null;
let folders = [];
let curId = null;
let pickedColor = "#c9b6f2";
let provider = null;
const CLOUD = !!(window.FIREBASE_CONFIG && window.FIREBASE_CONFIG.apiKey && !/ВСТАВЬ/i.test(window.FIREBASE_CONFIG.apiKey));
const cloud = () => (CLOUD && window.AG_CLOUD) || null;
let needProfile = false;
const COLORS = ["#c9b6f2", "#bfe3ff", "#ffc9c0", "#ffe3a8", "#b9e5c8", "#f7b7d6", "#9db8f5", "#d9c3a5"];

const saveUsers = () => localStorage.setItem("ag_users", JSON.stringify(users));
const saveFolders = () => {
  if (!user) return;
  localStorage.setItem("ag_f_" + user.id, JSON.stringify(folders));
  const c = cloud(); if (c) c.saveFolders(user.id, folders);
};
const curFolder = () => folders.find(f => f.id === curId);
async function sha(s) {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
}
function loginAs(u) {
  user = u; localStorage.setItem("ag_session", u.id);
  folders = JSON.parse(localStorage.getItem("ag_f_" + u.id) || "[]");
  renderUser(); renderFolders(); renderArchive(); openFolder(null);
}
function logout() {
  if (cloud()) { cloud().logout(); return; }
  localStorage.removeItem("ag_session"); user = null; folders = []; curId = null;
  renderUser(); renderFolders(); renderArchive(); openFolder(null);
}

/* ================= Шапка ================= */
function renderUser() {
  const b = $("#userBox");
  if (!user) {
    b.innerHTML = `<button class="btn small" data-open-auth="login">Войти</button><button class="btn primary small" data-open-auth="register">Регистрация</button>`;
  } else {
    b.innerHTML = `<div class="me"><img src="${user.avatar || PIXEL}" alt=""><span>${esc(user.nick)}</span></div>
      <button class="btn small" id="logoutBtn">Выйти</button>`;
    $("#logoutBtn").onclick = logout;
  }
}

/* ================= Окно входа / регистрации ================= */
function openAuth(tab = "register") {
  provider = null; setTab(tab); $("#authMsg").textContent = ""; $("#authModal").classList.add("open");
}
function setTab(tab) {
  $$(".tabs button").forEach(b => b.classList.toggle("on", b.dataset.tab === tab));
  $("#regForm").hidden = tab !== "register"; $("#loginForm").hidden = tab !== "login";
  const social = needProfile || (provider && provider !== "email");
  ["#regEmail", "#regPass"].forEach(s => { const l = $(s).closest("label"); l.hidden = !!social; $(s).required = !social; });
  $("#regForm button[type=submit]").textContent = social ? (needProfile ? "Сохранить профиль" : "Продолжить через " + (provider === "google" ? "Google" : "Apple")) : "Создать аккаунт";
}
function closeModals() { $$(".modal").forEach(m => m.classList.remove("open")); stopMemory(); }

async function resizeToDataUrl(file, size = 160) {
  const bmp = await createImageBitmap(file);
  const c = document.createElement("canvas"); c.width = c.height = size;
  const k = Math.max(size / bmp.width, size / bmp.height);
  const w = bmp.width * k, h = bmp.height * k;
  c.getContext("2d").drawImage(bmp, (size - w) / 2, (size - h) / 2, w, h);
  return c.toDataURL("image/jpeg", .85);
}

let regAvatarData = "";
$("#regAvatar").src = PIXEL;
$("#regPhoto").onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  regAvatarData = await resizeToDataUrl(f); $("#regAvatar").src = regAvatarData;
};

$("#regForm").onsubmit = async e => {
  e.preventDefault();
  const nick = $("#regNick").value.trim();
  const c = cloud();
  if (c) {
    $("#authMsg").textContent = "";
    try {
      if (needProfile) await c.saveProfile({ nick, avatar: regAvatarData });
      else await c.register($("#regEmail").value.trim(), $("#regPass").value, { nick, avatar: regAvatarData });
    } catch (err) { $("#authMsg").textContent = c.errText(err); }
    return;
  }
  const social = provider && provider !== "email";
  const email = social ? `${provider}:${nick.toLowerCase()}` : $("#regEmail").value.trim().toLowerCase();
  if (users.some(u => u.email === email)) { $("#authMsg").textContent = "Такой аккаунт уже есть — войдите."; return; }
  const u = { id: uid(), nick, email, avatar: regAvatarData, provider: social ? provider : "email",
              pass: social ? "" : await sha($("#regPass").value) };
  users.push(u); saveUsers(); loginAs(u); closeModals(); toast("Добро пожаловать, " + nick + "!");
};
$("#loginForm").onsubmit = async e => {
  e.preventDefault();
  const c = cloud();
  if (c) {
    $("#authMsg").textContent = "";
    try { await c.login($("#logEmail").value.trim(), $("#logPass").value); }
    catch (err) { $("#authMsg").textContent = c.errText(err); }
    return;
  }
  const email = $("#logEmail").value.trim().toLowerCase(), h = await sha($("#logPass").value);
  const u = users.find(x => x.email === email && x.pass === h);
  if (!u) { $("#authMsg").textContent = "Неверная почта или пароль."; return; }
  loginAs(u); closeModals(); toast("С возвращением, " + u.nick + "!");
};
$("#resetPass").onclick = async () => {
  const email = $("#logEmail").value.trim(), c = cloud();
  if (!c) { $("#authMsg").textContent = "Сброс пароля работает после подключения Firebase."; return; }
  if (!email) { $("#authMsg").textContent = "Введите почту в поле выше."; return; }
  try { await c.reset(email); $("#authMsg").textContent = "Письмо для сброса пароля отправлено."; }
  catch (err) { $("#authMsg").textContent = c.errText(err); }
};
$$(".prov").forEach(b => b.onclick = async () => {
  const p = b.dataset.provider; const c = cloud();
  if (c && p !== "email") {
    $("#authMsg").textContent = "";
    try { await c.social(p); } catch (err) { $("#authMsg").textContent = c.errText(err); }
    return;
  }
  if (p === "email") { provider = "email"; setTab($(".tabs .on").dataset.tab); $("#regEmail").focus(); return; }
  const isLogin = $(".tabs .on").dataset.tab === "login";
  const known = users.filter(u => u.provider === p);
  if (isLogin && known.length) { loginAs(known[known.length - 1]); closeModals(); toast("Вход через " + p); return; }
  provider = p; setTab("register");
  $("#authMsg").textContent = "Демо-режим: придумайте никнейм и выберите фото. Настоящий OAuth подключается через Firebase (см. README).";
});
document.addEventListener("click", e => {
  const o = e.target.closest("[data-open-auth]"); if (o) openAuth(o.dataset.openAuth);
  const t = e.target.closest("[data-tab]"); if (t && t.closest(".tabs")) setTab(t.dataset.tab);
  if (e.target.closest("[data-close]") || e.target.classList.contains("modal")) closeModals();
});
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModals(); });

/* ================= Папки ================= */
$("#swatches").innerHTML = COLORS.map((c, i) => `<div class="sw${i === 0 ? " on" : ""}" data-c="${c}" style="background:${c}"></div>`).join("");
$("#swatches").onclick = e => {
  const s = e.target.closest(".sw"); if (!s) return;
  pickedColor = s.dataset.c; $$(".sw").forEach(x => x.classList.toggle("on", x === s));
};
const folderSvg = c => `<svg viewBox="0 0 120 96"><path d="M6 20a8 8 0 0 1 8-8h30l10 12h52a8 8 0 0 1 8 8v52a8 8 0 0 1-8 8H14a8 8 0 0 1-8-8z" fill="${c}"/><path d="M6 36h108v52a8 8 0 0 1-8 8H14a8 8 0 0 1-8-8z" fill="#fff" opacity=".28"/></svg>`;

$("#folderForm").onsubmit = e => {
  e.preventDefault();
  if (!user) { toast("Сначала зарегистрируйтесь или войдите"); openAuth("register"); return; }
  const f = { id: uid(), name: $("#folderName").value.trim(), color: pickedColor, date: new Date().toISOString(),
              text: "", files: [], songUrl: "", songInfo: "", tempo: "", mode: "", memory: null };
  folders.unshift(f); saveFolders(); $("#folderName").value = "";
  renderFolders(); renderArchive(); openFolder(f.id); toast("Папка создана — откройте её и добавьте день");
};
function renderFolders() {
  const g = $("#folderGrid");
  g.innerHTML = folders.length ? folders.map(f => `<div class="fold${f.id === curId ? " on" : ""}" data-id="${f.id}">${folderSvg(f.color)}<small>${esc(f.name)}</small></div>`).join("")
    : `<p class="muted tiny" style="grid-column:1/-1">Пока пусто.</p>`;
}
$("#folderGrid").onclick = e => { const f = e.target.closest(".fold"); if (f) openFolder(f.dataset.id); };

async function openFolder(id) {
  curId = id; const f = curFolder();
  $("#wsEmpty").hidden = !!f; $("#wsBody").hidden = !f; renderFolders();
  if (!f) return;
  $("#bigFolder").style.setProperty("--c", f.color);
  $("#wsName").textContent = f.name; $("#wsDate").textContent = fmtDate(f.date);
  $("#dayText").value = f.text; $("#songUrl").value = f.songUrl; $("#songInfo").value = f.songInfo;
  $("#songTempo").value = f.tempo; $("#songMode").value = f.mode;
  await renderThumbs();
}
function syncDraft() {
  const f = curFolder(); if (!f) return;
  f.text = $("#dayText").value; f.songUrl = $("#songUrl").value.trim(); f.songInfo = $("#songInfo").value.trim();
  f.tempo = $("#songTempo").value; f.mode = $("#songMode").value; saveFolders();
}
$("#saveDraft").onclick = () => { syncDraft(); toast("Сохранено в папку"); };

/* ----- файлы ----- */
const drop = $("#drop");
$("#pickFiles").onclick = () => $("#fileInput").click();
$("#fileInput").onchange = e => addFiles(e.target.files);
["dragenter", "dragover"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("over"); }));
["dragleave", "drop"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("over"); }));
drop.addEventListener("drop", e => addFiles(e.dataTransfer.files));

async function addFiles(list) {
  const f = curFolder(); if (!f) return toast("Сначала откройте папку");
  for (const file of list) {
    const type = file.type.startsWith("image") ? "image" : file.type.startsWith("video") ? "video" : file.type.startsWith("audio") ? "audio" : null;
    if (!type) continue;
    const id = uid(); await DB.put(id, file); f.files.push({ id, type, name: file.name });
  }
  saveFolders(); renderThumbs(); renderArchive();
}
async function renderThumbs() {
  const f = curFolder(); const box = $("#thumbs"); box.innerHTML = "";
  for (const m of f.files) {
    const u = await fileUrl(m.id); if (!u) continue; const d = document.createElement("div"); d.className = "th"; d.title = m.name;
    d.innerHTML = (m.type === "image" ? `<img src="${u}" alt="">` : m.type === "video" ? `<video src="${u}" muted></video>` : "<small>аудио</small>") + `<button data-del="${m.id}">×</button>`;
    box.appendChild(d);
  }
}
$("#thumbs").onclick = async e => {
  const id = e.target.dataset.del; const f = curFolder(); if (!id || !f) return;
  f.files = f.files.filter(x => x.id !== id); await DB.del(id); delete urlCache[id]; saveFolders(); renderThumbs(); renderArchive();
};

/* ================= Анализ дня ================= */
const MOODS = {
  calm:      { name: "спокойный", tail: "в тихих тонах", anchors: ["#f3dcc0", "#e5b98d", "#b9c9a6", "#fff1dc"], sat: 1.0, con: .95, bri: 1.04, sep: .18, blur: .3, grain: .16, dur: 10, comp: "strokes",
               ref: "Клод Моне: мягкие мазки и тёплый рассеянный свет", voice: { rate: .85, pitch: .9 }, voiceName: "тихий и тёплый", bg: "#fff6ea" },
  cozy:      { name: "уютный", tail: "и тёплый свет", anchors: ["#f2c27d", "#d98c52", "#8a5a3c", "#fff0d6"], sat: 1.12, con: 1.0, bri: 1.0, sep: .3, blur: 0, grain: .22, dur: 9, comp: "strokes",
               ref: "плёночная фотография: охра, зерно, тёплые тени", voice: { rate: .88, pitch: .95 }, voiceName: "мягкий и тёплый", bg: "#fff1de" },
  tense:     { name: "собранный", tail: "в серых тонах", anchors: ["#2d3a5c", "#586a8f", "#9aa8c0", "#e9eef6"], sat: .75, con: 1.2, bri: .92, sep: 0, blur: 0, grain: .12, dur: 5, comp: "geometry",
               ref: "Кандинский: жёсткая сетка, линии и геометрические пятна", voice: { rate: 1.05, pitch: .85 }, voiceName: "ровный и чёткий", bg: "#eef2f9" },
  energetic: { name: "живой", tail: "на одном дыхании", anchors: ["#ff7aa8", "#ffb84d", "#4dd0e1", "#7c5cff"], sat: 1.3, con: 1.12, bri: 1.05, sep: 0, blur: 0, grain: .1, dur: 4, comp: "collage",
               ref: "коллаж и резкий монтажный ритм", voice: { rate: 1.12, pitch: 1.12 }, voiceName: "быстрый и яркий", bg: "#fff0f6" },
  sad:       { name: "тихо-грустный", tail: "в мягкой тишине", anchors: ["#b8c5d8", "#8e9eb8", "#d9dee8", "#f3f3f7"], sat: .6, con: .92, bri: 1.02, sep: .05, blur: .6, grain: .2, dur: 12, comp: "minimal",
               ref: "японская минималистичная графика: воздух и пустота", voice: { rate: .8, pitch: .85 }, voiceName: "низкий и медленный", bg: "#f1f3f8" },
  joy:       { name: "радостный", tail: "в ярких красках", anchors: ["#ffd36e", "#ff9eb5", "#9fe0ff", "#c9b6f2"], sat: 1.25, con: 1.05, bri: 1.08, sep: 0, blur: 0, grain: .08, dur: 6, comp: "strokes",
               ref: "яркая акварельная палитра и лёгкий свет", voice: { rate: 1.05, pitch: 1.15 }, voiceName: "светлый и улыбчивый", bg: "#fff8e8" },
};
const KEYS = {
  calm:      /парк|спокой|тих|закат|пруд|прогул|гуля|озер|книг|медлен|размеренн|уют/g,
  cozy:      /какао|чай|кофе|плед|свеч|дом[аеу]?\b|тепл|камин|осен|листь|выпечк|разговарив/g,
  tense:     /срочн|дедлайн|сдач|офис|работ|экзамен|устал|спешк|проект|код|ночь|нервн|напряж/g,
  energetic: /бег|вечеринк|концерт|быстр|танц|ярк|смех|друзь|море|прыг|гонк|фестивал|драйв/g,
  sad:       /груст|скуч|дожд|один[оа]?\b|тоск|прощ|слёз|слез|пусто|расстал|одинок/g,
  joy:       /рад[ао]?\b|счасть|ура|день рождения|побед|любим|праздник|подарок|улыб|свадьб/g,
};

async function analyzePhoto(blob) {
  const bmp = await createImageBitmap(blob); const S = 48;
  const c = document.createElement("canvas"); c.width = c.height = S;
  const x = c.getContext("2d", { willReadFrequently: true }); x.drawImage(bmp, 0, 0, S, S);
  const d = x.getImageData(0, 0, S, S).data; let R = 0, G = 0, B = 0, n = 0, sat = 0; const bins = {};
  for (let i = 0; i < d.length; i += 4) {
    const r = d[i], g = d[i + 1], b = d[i + 2]; R += r; G += g; B += b; n++;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b); sat += mx ? (mx - mn) / mx : 0;
    const k = (r >> 5) + "," + (g >> 5) + "," + (b >> 5); (bins[k] ||= { n: 0, r: 0, g: 0, b: 0 }); const o = bins[k]; o.n++; o.r += r; o.g += g; o.b += b;
  }
  const dom = Object.values(bins).sort((a, b) => b.n - a.n).slice(0, 3)
    .map(o => "#" + [o.r, o.g, o.b].map(v => Math.round(v / o.n).toString(16).padStart(2, "0")).join(""));
  return { r: R / n, g: G / n, b: B / n, bright: (R + G + B) / n / 3 / 255, sat: sat / n, dom };
}

function inferTitle(text, mood) {
  const t = text.toLowerCase();
  const has = re => re.test(t);
  const season = has(/осен|листь|жёлт|желт/) ? ["Осенний", "осенью"] : has(/зим|снег|мороз/) ? ["Зимний", "зимой"] : has(/весн|капел|цвет[уе]т/) ? ["Весенний", "весной"] : has(/лето|летн|жар[аеу]|пляж|купа/) ? ["Летний", "летом"] : null;
  const timeWord = has(/ноч/) ? "Ночь" : has(/вечер|закат|сумерк/) ? "Вечер" : has(/утр|рассвет|завтрак/) ? "Утро" : null;
  const places = [[/парк/, "в парке"], [/пруд/, "у пруда"], [/офис/, "в офисе"], [/мор[еяю]/, "у моря"], [/лес/, "в лесу"], [/квартир|дома\b/, "дома"],
    [/кафе/, "в кафе"], [/гор[аыу]\b/, "в горах"], [/озер/, "у озера"], [/набережн/, "на набережной"], [/универ|кампус/, "в университете"], [/город/, "в городе"]];
  const comps = [[/девушк/, "с девушкой"], [/парн|молод(ой|ым) человек/, "с парнем"], [/друз/, "с друзьями"], [/семь|родител/, "с семьёй"], [/мам[аойу]/, "с мамой"], [/брат/, "с братом"], [/сестр/, "с сестрой"], [/собак/, "с собакой"]];
  const place = (places.find(p => p[0].test(t)) || [])[1];
  const comp = (comps.find(p => p[0].test(t)) || [])[1];
  const extra = has(/сдач|дедлайн|срочн/) ? "перед сдачей" : has(/какао/) ? "и какао" : has(/кофе/) ? "и кофе" : has(/чай/) ? "и чай" : has(/дожд/) ? "под дождём" : has(/концерт/) ? "и концерт" : "";

  let words;
  if (timeWord) words = [timeWord, season && season[1], comp, place, extra];
  else if (season) words = [season[0], "день", place, comp, extra];
  else words = ["День", place, comp, extra];
  let arr = words.filter(Boolean).join(" ").split(" ");
  if (arr.length > 7) arr = words.filter((w, i) => w && w !== comp).join(" ").split(" ");
  if (arr.length > 7) arr = arr.slice(0, 7);
  if (arr.length < 3) arr = arr.concat(MOODS[mood].tail.split(" "));
  if (arr.length < 3) arr.push("дня");
  const s = arr.join(" "); return s[0].toUpperCase() + s.slice(1);
}

async function buildMemory(f) {
  const why = []; const sc = { calm: 0, cozy: 0, tense: 0, energetic: 0, sad: 0, joy: 0 };
  const t = f.text.toLowerCase();
  for (const k in KEYS) { const m = t.match(KEYS[k]); if (m) { sc[k] += Math.min(m.length, 4); } }
  const topText = Object.entries(sc).sort((a, b) => b[1] - a[1])[0];
  if (topText[1] > 0) why.push(`Текст: ключевые слова задают настроение «${MOODS[topText[0]].name}».`);

  const info = (f.songInfo + " " + f.songUrl).toLowerCase();
  const tempo = f.tempo, mode = f.mode;
  if (tempo === "slow") { sc.calm += 1; sc.sad += .5; } if (tempo === "fast") sc.energetic += 1.5;
  if (mode === "minor") { sc.sad += 1; sc.tense += .5; } if (mode === "major") { sc.joy += .8; sc.cozy += .3; }
  const genres = [[/джаз|jazz|синатр|sinatra/, "cozy", "джаз"], [/электрон|electro|techno|house|synth|синтвейв/, "tense", "электроника"], [/рок|rock|metal|панк/, "energetic", "рок"],
    [/класс|classic|шопен|моцарт|бах/, "calm", "классика"], [/lo-?fi|лоу-?фай|эмбиент|ambient/, "calm", "lo-fi"], [/поп|pop/, "joy", "поп"]];
  const g = genres.find(x => x[0].test(info)); if (g) { sc[g[1]] += 1; why.push(`Песня: жанр «${g[2]}» подталкивает оформление к настроению «${MOODS[g[1]].name}».`); }
  const yr = (info.match(/\b(19[0-9]{2}|20[0-2][0-9])\b/) || [])[1];

  const imgs = f.files.filter(x => x.type === "image"); const stats = [];
  for (const m of imgs) { const b = await DB.get(m.id); if (b) stats.push(await analyzePhoto(b)); }
  let dom = [];
  if (stats.length) {
    const avg = k => stats.reduce((a, s) => a + s[k], 0) / stats.length;
    const bright = avg("bright"), sat = avg("sat"), warm = avg("r") - avg("b");
    if (bright < .35) { sc.tense += .6; sc.sad += .3; why.push("Фото тёмные — композиция уходит в собранные, сдержанные тона."); }
    if (bright > .65 && sat > .35) { sc.joy += .7; why.push("Фото светлые и насыщенные — добавляем радости и воздуха."); }
    if (sat < .2) sc.sad += .5;
    if (warm > 25) { sc.cozy += .7; why.push("Фото тёплые (охра, оранжевый) — сохраняем плёночную теплоту."); }
    dom = stats.flatMap(s => s.dom).slice(0, 2);
  }
  let mood = Object.entries(sc).sort((a, b) => b[1] - a[1])[0]; mood = mood[1] > 0 ? mood[0] : "calm";
  const M = MOODS[mood];

  let sat = M.sat, con = M.con, bri = M.bri, sep = M.sep, blur = M.blur, grain = M.grain, dur = M.dur;
  if (tempo === "slow") { dur += 2; blur += .2; why.push(`Медленный темп песни — кадры меняются реже (каждые ${dur} с), больше воздуха.`); }
  if (tempo === "fast") { dur = Math.max(3, dur - 2); con += .08; why.push(`Быстрый темп — короткие кадры (каждые ${dur} с) и больше контраста.`); }
  if (mode === "minor") { sat -= .12; sep = Math.max(0, sep - .1); why.push("Минор — приглушённые, более холодные цвета."); }
  if (mode === "major") { sat += .1; bri += .02; why.push("Мажор — чуть теплее и ярче."); }
  if (yr && +yr < 1985) { sep += .2; grain += .08; why.push(`Песня ${yr} года — добавляем плёночное зерно и сепию эпохи.`); }

  const palette = [...dom, ...M.anchors].slice(0, 5);
  const media = f.files.filter(x => x.type === "video").length;
  const format = media ? "film" : imgs.length >= 6 ? "collage" : imgs.length === 1 ? "postcard" : "film";
  const fmtName = { film: "короткое видео с музыкой", collage: "коллаж-мозаика", postcard: "анимированная открытка" }[format];
  why.push(`Формат: ${fmtName} — выбран автоматически по ${imgs.length} фото${media ? " и видео" : ""}.`);
  why.push(`Художественный приём: ${M.ref}.`);
  why.push(`Озвучка: голос ${M.voiceName} (скорость ${M.voice.rate}, высота ${M.voice.pitch}) под настроение дня.`);
  why.push("Постоянно во всех днях: сетка, шрифты, дата, рукописная подпись и рамка фото — это делает ленту цельной.");

  return { title: inferTitle(f.text, mood), mood, palette, format, dur, grain: +grain.toFixed(2), comp: M.comp,
    filter: `saturate(${sat.toFixed(2)}) contrast(${con.toFixed(2)}) brightness(${bri.toFixed(2)}) sepia(${Math.max(0, sep).toFixed(2)}) blur(${blur.toFixed(1)}px)`,
    voice: M.voice, bg: M.bg, why, builtAt: new Date().toISOString() };
}

$("#buildMemory").onclick = async () => {
  const f = curFolder(); if (!f) return; syncDraft();
  if (!f.text.trim()) return toast("Напишите, как прошёл день");
  if (!f.files.some(x => x.type === "image")) return toast("Добавьте хотя бы одно фото");
  if (!f.songUrl && !f.songInfo && !f.files.some(x => x.type === "audio")) toast("Совет: добавьте песню — она влияет на оформление");
  const b = $("#buildMemory"); b.disabled = true; b.textContent = "Собираю…";
  try {
    f.memory = await buildMemory(f); f.name = f.memory.title; saveFolders();
    renderFolders(); renderArchive(); $("#wsName").textContent = f.name; openMemory(f);
  } finally { b.disabled = false; b.textContent = "Собрать воспоминание"; }
};

/* ================= Показ воспоминания ================= */
let slideTimer = null, speaking = false;
function stopMemory() { clearInterval(slideTimer); slideTimer = null; speechSynthesis.cancel(); speaking = false; $$("#memBody audio").forEach(a => a.pause()); }

function embedFor(url) {
  let m = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/);
  if (m) return `<iframe src="https://www.youtube.com/embed/${m[1]}" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
  m = url.match(/open\.spotify\.com\/(track|album|playlist)\/(\w+)/);
  if (m) return `<iframe src="https://open.spotify.com/embed/${m[1]}/${m[2]}" allow="encrypted-media"></iframe>`;
  return url ? `<a class="btn small" href="${esc(url)}" target="_blank" rel="noopener">Открыть песню</a>` : "";
}

function shapesFor(comp, pal) {
  const p = i => pal[i % pal.length];
  if (comp === "geometry") return `<svg class="shape" viewBox="0 0 400 300" preserveAspectRatio="none" style="inset:0;width:100%;height:100%">
    <circle cx="320" cy="70" r="46" fill="none" stroke="${p(2)}" stroke-width="3"/><circle cx="320" cy="70" r="22" fill="${p(1)}"/>
    <line x1="0" y1="250" x2="400" y2="60" stroke="${p(3)}" stroke-width="2"/><line x1="40" y1="0" x2="190" y2="300" stroke="${p(2)}" stroke-width="1.5"/>
    <polygon points="60,260 130,210 150,270" fill="${p(0)}"/><rect x="230" y="190" width="70" height="70" fill="none" stroke="${p(3)}" stroke-width="2" transform="rotate(18 265 225)"/></svg>`;
  if (comp === "collage") return `<svg class="shape" viewBox="0 0 400 300" preserveAspectRatio="none" style="inset:0;width:100%;height:100%;opacity:.4">
    ${[0, 1, 2, 3].map(i => `<rect x="${-40 + i * 120}" y="-20" width="46" height="360" fill="${p(i)}" transform="rotate(14 ${i * 120} 150)"/>`).join("")}</svg>`;
  if (comp === "minimal") return `<svg class="shape" viewBox="0 0 400 300" preserveAspectRatio="none" style="inset:0;width:100%;height:100%">
    <circle cx="330" cy="80" r="26" fill="${p(0)}" opacity=".8"/><line x1="40" y1="250" x2="360" y2="250" stroke="${p(1)}" stroke-width="1.5"/></svg>`;
  return [0, 1, 2].map(i => `<div class="shape" style="width:${180 + i * 60}px;height:${180 + i * 60}px;border-radius:50%;background:${p(i)};filter:blur(46px);left:${10 + i * 28}%;top:${20 + (i % 2) * 36}%"></div>`).join("");
}

async function openMemory(f) {
  stopMemory(); const m = f.memory; if (!m) { openFolder(f.id); location.hash = "studio"; return; }
  const media = [];
  for (const x of f.files.filter(x => x.type === "image" || x.type === "video")) { const url = await fileUrl(x.id); if (url) media.push({ type: x.type, url }); }
  const audio = f.files.find(x => x.type === "audio"); const audioUrl = audio ? await fileUrl(audio.id) : null;
  const pal = m.palette;
  let stage;
  if (m.format === "collage") {
    stage = `<div style="position:absolute;inset:0;display:grid;grid-template-columns:repeat(3,1fr);gap:4px;filter:${m.filter}">${media.map(x => `<div style="background:url('${x.url}') center/cover"></div>`).join("")}</div>`;
  } else {
    stage = media.map((x, i) => x.type === "video"
      ? `<video class="slide${i === 0 ? " on" : ""}" src="${x.url}" muted loop playsinline style="width:100%;height:100%;object-fit:cover;filter:${m.filter}"></video>`
      : `<div class="slide${i === 0 ? " on" : ""}" style="background-image:url('${x.url}');filter:${m.filter};--dur:${m.dur + 2}s;--tx:${i % 2 ? -1.5 : 1.5}%;--ty:${i % 3 ? -1.5 : 1.5}%"></div>`).join("");
  }
  const frame = m.format === "postcard" ? "box-shadow:inset 0 0 0 14px #fff;" : "";
  $("#memBody").innerHTML = `<div class="mem" style="--mem-bg:${m.bg}">
    <div class="stage" style="--grain:${m.grain};${frame}">
      ${stage}${shapesFor(m.comp, pal)}
      <div class="tint" style="background:linear-gradient(135deg,${pal[0]},${pal[2] || pal[1]})"></div><div class="grain"></div>
      <div class="date">${fmtDate(f.date)}</div><div class="sign">${esc(user ? user.nick : "")}</div>
    </div>
    <div class="mem-side">
      <h3>${esc(m.title)}</h3>
      <p class="muted tiny">Настроение: ${MOODS[m.mood].name} · ${{ film: "видео с музыкой", collage: "коллаж", postcard: "анимированная открытка" }[m.format]}</p>
      <div class="pal">${pal.map(c => `<i style="background:${c}" title="${c}"></i>`).join("")}</div>
      <p class="text">${esc(f.text)}</p>
      <div class="player">${audioUrl ? `<audio controls src="${audioUrl}"></audio>` : embedFor(f.songUrl)}</div>
      ${f.songInfo ? `<p class="muted tiny">♪ ${esc(f.songInfo)}</p>` : ""}
      <div class="why"><b>Почему день выглядит так</b><ul style="padding-left:18px;margin:6px 0 0">${m.why.map(w => `<li>${esc(w)}</li>`).join("")}</ul></div>
      <div class="mem-actions"><button class="btn primary small" id="speakBtn">Озвучить</button><button class="btn small" id="rebuildBtn">Пересобрать</button></div>
    </div></div>`;
  $("#memModal").classList.add("open");
  const slides = $$("#memBody .slide"); let i = 0;
  slides.forEach(s => s.tagName === "VIDEO" && s.play().catch(() => { }));
  if (slides.length > 1) slideTimer = setInterval(() => {
    slides[i].classList.remove("on"); i = (i + 1) % slides.length;
    const n = slides[i]; n.style.animation = "none"; void n.offsetWidth; n.style.animation = ""; n.classList.add("on");
  }, m.dur * 1000);
  const au = $("#memBody audio"); if (au) au.play().catch(() => { });
  $("#speakBtn").onclick = () => speak(f.text, m);
  $("#rebuildBtn").onclick = async () => { f.memory = await buildMemory(f); f.name = f.memory.title; saveFolders(); renderFolders(); renderArchive(); openMemory(f); };
}
function speak(text, m) {
  if (speaking) { speechSynthesis.cancel(); speaking = false; return; }
  const u = new SpeechSynthesisUtterance(text); u.lang = "ru-RU"; u.rate = m.voice.rate; u.pitch = m.voice.pitch;
  const v = speechSynthesis.getVoices().find(v => v.lang.startsWith("ru")); if (v) u.voice = v;
  u.onend = () => (speaking = false); speaking = true; speechSynthesis.speak(u);
}

/* ================= Архив (дневник) ================= */
async function renderArchive() {
  const g = $("#archiveGrid");
  if (!user) { g.innerHTML = `<p class="none">Войдите, чтобы увидеть свой дневник.</p>`; return; }
  if (!folders.length) { g.innerHTML = `<p class="none">Дневник пока пуст. Создайте первую папку дня выше.</p>`; return; }
  g.innerHTML = "";
  for (const f of folders) {
    const img = f.files.find(x => x.type === "image"); const u = img ? await fileUrl(img.id) : null; const m = f.memory;
    const d = document.createElement("div"); d.className = "day";
    d.innerHTML = `<div class="cover" style="${u ? `background-image:url('${u}');` : `background:${f.color};`}${m ? `--tint:linear-gradient(135deg,${m.palette[0]},${m.palette[2] || m.palette[1]});filter:${m.filter};` : ""}"></div>
      <div class="meta"><h4>${esc(f.name)}</h4><small>${fmtDate(f.date)}${m ? " · " + MOODS[m.mood].name : " · черновик"}</small>
      ${m ? `<div class="dots">${m.palette.map(c => `<i style="background:${c}"></i>`).join("")}</div>` : ""}</div>`;
    d.onclick = () => m ? openMemory(f) : (openFolder(f.id), $("#studio").scrollIntoView());
    g.appendChild(d);
  }
}

/* ================= Демо-дни (3 разных настроения) ================= */
function art(kind, seed = 0) {
  const c = document.createElement("canvas"); c.width = 900; c.height = 600; const x = c.getContext("2d");
  const rnd = (() => { let s = 7 + seed * 13; return () => (s = (s * 16807) % 2147483647) / 2147483647; })();
  if (kind === "autumn") {
    const g = x.createLinearGradient(0, 0, 0, 600); g.addColorStop(0, "#f3d9a4"); g.addColorStop(1, "#c9783a"); x.fillStyle = g; x.fillRect(0, 0, 900, 600);
    for (let i = 0; i < 9; i++) { x.fillStyle = "rgba(70,40,20,.55)"; x.fillRect(40 + i * 100 + rnd() * 30, 120, 12 + rnd() * 12, 480); }
    for (let i = 0; i < 380; i++) { x.fillStyle = ["#e8a33d", "#d2691e", "#f6c453", "#b5512a"][i % 4]; x.globalAlpha = .75; x.beginPath(); x.ellipse(rnd() * 900, rnd() * 600, 8 + rnd() * 16, 5 + rnd() * 9, rnd() * 3, 0, 7); x.fill(); }
  } else if (kind === "office") {
    const g = x.createLinearGradient(0, 0, 900, 600); g.addColorStop(0, "#1b2440"); g.addColorStop(1, "#3a4a72"); x.fillStyle = g; x.fillRect(0, 0, 900, 600);
    for (let r = 0; r < 6; r++) for (let q = 0; q < 10; q++) { x.fillStyle = rnd() > .55 ? "rgba(190,210,255,.8)" : "rgba(80,100,150,.4)"; x.fillRect(30 + q * 86, 30 + r * 52, 64, 34); }
    x.fillStyle = "#cfe0ff"; x.fillRect(220 + seed * 60, 380, 300, 170); x.fillStyle = "#1b2440"; x.fillRect(236 + seed * 60, 394, 268, 130);
  } else {
    const g = x.createLinearGradient(0, 0, 0, 600); g.addColorStop(0, "#9fd3ff"); g.addColorStop(.5, "#ffd0c2"); g.addColorStop(.52, "#6aa6e8"); g.addColorStop(1, "#2f5fa8"); x.fillStyle = g; x.fillRect(0, 0, 900, 600);
    x.fillStyle = "#fff1c9"; x.beginPath(); x.arc(450 + seed * 90, 290, 62, 0, 7); x.fill();
    for (let i = 0; i < 60; i++) { x.strokeStyle = "rgba(255,255,255,.4)"; x.beginPath(); x.moveTo(rnd() * 900, 320 + rnd() * 270); x.lineTo(rnd() * 900, 320 + rnd() * 270); x.stroke(); }
  }
  return new Promise(r => c.toBlob(r, "image/jpeg", .85));
}
$("#seedDemo").onclick = async () => {
  if (!user) { toast("Сначала зарегистрируйтесь или войдите"); return openAuth("register"); }
  const demos = [
    { name: "demo", kind: "autumn", color: "#ffe3a8", text: "Гуляли по парку, всё в жёлтых листьях, было холодно, но мы пили какао и долго разговаривали с девушкой у пруда.", songInfo: "Frank Sinatra — джаз, 1957", tempo: "slow", mode: "major" },
    { name: "demo", kind: "office", color: "#9db8f5", text: "Срочная сдача проекта, ночь в офисе, кофе и код. В наушниках электронная музыка, все в напряжении.", songInfo: "Synthwave — электроника, 2019", tempo: "fast", mode: "minor" },
    { name: "demo", kind: "sea", color: "#f7b7d6", text: "Поехали с друзьями к морю, смех, закат и танцы на пляже. Лето, счастье, самый яркий день.", songInfo: "Pop — поп, 2012", tempo: "fast", mode: "major" },
  ];
  $("#seedDemo").disabled = true;
  for (const d of demos) {
    const f = { id: uid(), name: d.name, color: d.color, date: new Date(Date.now() - folders.length * 864e5).toISOString(), text: d.text, files: [], songUrl: "", songInfo: d.songInfo, tempo: d.tempo, mode: d.mode, memory: null };
    for (let i = 0; i < 2; i++) { const id = uid(); await DB.put(id, await art(d.kind, i)); f.files.push({ id, type: "image", name: d.kind + i + ".jpg" }); }
    f.memory = await buildMemory(f); f.name = f.memory.title; folders.unshift(f);
  }
  saveFolders(); renderFolders(); renderArchive(); $("#seedDemo").disabled = false; toast("Добавлено 3 дня разного настроения — откройте «Дневник»");
};

/* ================= ИИ-помощник (правила, без сервера) ================= */
const aiLog = $("#aiLog");
function say(t, me) { const d = document.createElement("div"); d.className = "msg " + (me ? "me" : "bot"); d.textContent = t; aiLog.appendChild(d); aiLog.scrollTop = 1e6; }
function aiReply(q) {
  const t = q.toLowerCase(), f = curFolder();
  if (/назван|назови|придумай/.test(t)) { const txt = f ? f.text : q; return txt.trim().length > 12 ? `Предлагаю название: «${inferTitle(txt, "calm")}».` : "Напишите хотя бы пару предложений о дне — и я придумаю название (3–7 слов)."; }
  if (/настроен/.test(t)) { const txt = (f ? f.text : q).toLowerCase(); let best = ["calm", 0]; for (const k in KEYS) { const n = (txt.match(KEYS[k]) || []).length; if (n > best[1]) best = [k, n]; } return `Похоже на настроение «${MOODS[best[0]].name}». Приём: ${MOODS[best[0]].ref}.`; }
  if (/цвет|палитр/.test(t)) return "Палитра собирается из доминирующих цветов ваших фото и «якорных» цветов настроения. Тёплые фото — охра; тёмные — сине-серые тона.";
  if (/песн|музык|трек/.test(t)) return "Песня влияет на оформление: медленный темп — реже смена кадров, минор — приглушённые цвета, старая эпоха — плёночное зерно. Укажите исполнителя, жанр, год, темп и лад.";
  if (/озвуч|голос/.test(t)) return "Кнопка «Озвучить» читает запись голосом, подобранным под день: тихий и тёплый для спокойного вечера, быстрый и яркий для насыщенного дня.";
  if (/как|начат|привет|что/.test(t)) return "1) Создайте папку и выберите цвет. 2) Откройте её, напишите про день и добавьте фото и песню. 3) Нажмите «Собрать воспоминание». 4) Листайте дневник ниже.";
  return "Могу придумать название дня, определить настроение по тексту, объяснить палитру или рассказать, как песня влияет на оформление. Спросите!";
}
$("#aiFab").onclick = () => $("#aiPanel").classList.toggle("open");
$("#aiClose").onclick = () => $("#aiPanel").classList.remove("open");
$("#aiForm").onsubmit = e => { e.preventDefault(); const v = $("#aiInput").value.trim(); if (!v) return; say(v, true); $("#aiInput").value = ""; setTimeout(() => say(aiReply(v)), 350); };
say("Привет! Я помощник ArtTech Genesis. Помогу придумать название дня, объясню настроение и палитру.");

/* ================= Мост к Firebase (auth.js) ================= */
window.AG = {
  onAuth(u, needs, list, hint) {
    if (!u) { needProfile = false; user = null; folders = []; curId = null; renderUser(); renderFolders(); renderArchive(); openFolder(null); return; }
    if (needs) {   // вход через Google/Apple впервые: просим никнейм и фото
      needProfile = true; user = null; openAuth("register");
      $("#regNick").value = (hint && hint.name) || "";
      $("#authMsg").textContent = "Последний шаг: придумайте никнейм и выберите фото профиля.";
      return;
    }
    const first = !user; needProfile = false; $("#authModal").classList.remove("open");
    user = { id: u.id, nick: u.nick, avatar: u.avatar || "", email: u.email || "" };
    folders = (list || []).sort((x, y) => new Date(y.date) - new Date(x.date));
    renderUser(); renderFolders(); renderArchive(); openFolder(null);
    if (first) toast("Привет, " + user.nick + "!");
  },
};

/* ================= Старт ================= */
const sid = localStorage.getItem("ag_session"); const su = CLOUD ? null : users.find(u => u.id === sid);
renderUser(); if (su) loginAs(su); else { renderFolders(); renderArchive(); }
